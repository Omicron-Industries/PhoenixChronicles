package net.phoenixvine.chronicles.common.filter;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;

public interface IItemFilter {

    boolean test(ItemStack stack);

    String describe();

    CompoundTag serialize();

    default ItemStack getDisplayStack() {
        return ItemStack.EMPTY;
    }
}
