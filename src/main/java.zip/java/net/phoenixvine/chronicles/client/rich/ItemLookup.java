package net.phoenixvine.chronicles.client.rich;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;
import net.phoenixvine.chronicles.client.screen.ChronicleOverviewScreen;
import net.phoenixvine.chronicles.common.model.QuestNode;
import net.phoenixvine.chronicles.common.model.QuestReward;
import net.phoenixvine.chronicles.common.model.QuestTask;
import net.phoenixvine.chronicles.common.registry.QuestTreeRegistry;

import java.util.ArrayList;
import java.util.List;

public final class ItemLookup {

    private ItemLookup() {}

    public static void performLookup() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        ItemStack stack = getInspectedItem(mc);
        if (stack.isEmpty()) {
            mc.player.displayClientMessage(Component.translatable("phoenix_chronicles.ui.item_lookup_no_item"), true);
            return;
        }

        ResourceLocation itemId = ForgeRegistries.ITEMS.getKey(stack.getItem());
        if (itemId == null) return;

        List<QuestNode> matches = findQuestsRequiring(stack, itemId);
        if (matches.isEmpty()) {
            mc.player.displayClientMessage(
                    Component.translatable("phoenix_chronicles.ui.item_lookup_no_quest", stack.getHoverName()), true);
            return;
        }

        if (matches.size() == 1) {
            QuestNode target = matches.get(0);
            ChronicleOverviewScreen screen = new ChronicleOverviewScreen();
            mc.setScreen(screen);
            screen.navigateToNode(target);
            return;
        }

        mc.setScreen(new net.phoenixvine.chronicles.client.screen.ItemLookupResultsScreen(stack, matches));
    }

    private static ItemStack getInspectedItem(Minecraft mc) {
        if (mc.screen instanceof AbstractContainerScreen<?> containerScreen) {
            Slot hovered = containerScreen.hoveredSlot;
            if (hovered != null && hovered.hasItem()) return hovered.getItem();
        }
        ItemStack held = mc.player.getMainHandItem();
        if (!held.isEmpty()) return held;
        return mc.player.getOffhandItem();
    }

    private static List<QuestNode> findQuestsRequiring(ItemStack stack, ResourceLocation itemId) {
        List<QuestNode> matches = new ArrayList<>();
        for (QuestNode node : QuestTreeRegistry.getAllQuests().values()) {
            if (node.isLinkStub()) continue;
            if (referencesItem(node, stack, itemId)) matches.add(node);
        }
        return matches;
    }

    private static boolean referencesItem(QuestNode node, ItemStack stack, ResourceLocation itemId) {
        for (QuestTask task : node.getTasks()) {

            if (task.matchesItem(stack)) return true;
        }
        for (QuestReward reward : node.getRewards()) {
            if (reward instanceof QuestReward.ItemReward ir) {
                ResourceLocation id = ForgeRegistries.ITEMS.getKey(ir.getItem());
                if (id != null && id.equals(itemId)) return true;
            }
        }
        if (node.getIconItem() != null) {
            ResourceLocation id = ForgeRegistries.ITEMS.getKey(node.getIconItem());
            return id != null && id.equals(itemId);
        }
        return false;
    }
}
