package net.phoenixvine.chronicles.integration.kubejs;

import net.minecraftforge.fml.loading.FMLEnvironment;
import net.phoenixvine.chronicles.QuestAPI;
import net.phoenixvine.chronicles.client.render.IQuestBackground;
import net.phoenixvine.chronicles.client.render.background.BackgroundEffect;
import net.phoenixvine.chronicles.client.render.background.BackgroundEffects;
import net.phoenixvine.chronicles.client.render.background.GlitchShearBackground;
import net.phoenixvine.chronicles.client.render.background.QuestBackgroundBuilder;
import net.phoenixvine.chronicles.client.render.background.SunBackground;
import net.phoenixvine.chronicles.common.event.PhoenixQuestScriptRewardEvent;
import net.phoenixvine.chronicles.common.event.QuestEvent;
import net.phoenixvine.chronicles.common.flag.PhoenixQuestFlags;
import net.phoenixvine.chronicles.common.model.QuestNode;
import net.phoenixvine.chronicles.common.model.QuestState;
import net.phoenixvine.chronicles.common.model.QuestTask;
import net.phoenixvine.chronicles.common.registry.PhoenixTaskRegistry;
import net.phoenixvine.chronicles.common.registry.QuestBackgroundRegistry;
import net.phoenixvine.chronicles.common.tasks.ScriptTask;

import dev.latvian.mods.kubejs.KubeJSPlugin;
import dev.latvian.mods.kubejs.script.BindingsEvent;
import dev.latvian.mods.kubejs.script.ScriptType;
import dev.latvian.mods.kubejs.util.ClassFilter;
import org.jetbrains.annotations.NotNull;

public class PhoenixChroniclesKubeJSPlugin extends KubeJSPlugin {

    @Override
    public void registerClasses(ScriptType type, @NotNull ClassFilter filter) {
        filter.allow(QuestAPI.class);
        filter.allow(QuestState.class);
        filter.allow(QuestNode.class);

        filter.allow(QuestEvent.class);
        filter.allow(PhoenixQuestScriptRewardEvent.class);

        filter.allow(QuestTask.class);
        filter.allow(ScriptTask.class);
        filter.allow(PhoenixTaskRegistry.class);
        filter.allow(PhoenixTaskRegistry.Builder.class);
        filter.allow(PhoenixTaskRegistry.FieldDef.class);
        filter.allow(PhoenixQuestFlags.class);

        if (FMLEnvironment.dist.isClient()) {
            filter.allow(QuestBackgroundRegistry.class);
            filter.allow(QuestBackgroundBuilder.class);
            filter.allow(QuestBackgroundBuilder.BlendMode.class);
            filter.allow(BackgroundEffects.class);
            filter.allow(BackgroundEffect.class);
            filter.allow(IQuestBackground.class);
            filter.allow(SunBackground.class);
            filter.allow(GlitchShearBackground.class);
        }
    }

    @Override
    public void registerBindings(@NotNull BindingsEvent event) {
        event.add("QuestAPI", QuestAPI.class);
        event.add("PhoenixTaskRegistry", PhoenixTaskRegistry.class);
        event.add("PhoenixQuestFlags", PhoenixQuestFlags.class);

        if (FMLEnvironment.dist.isClient()) {
            event.add("QuestBackgroundRegistry", QuestBackgroundRegistry.class);
            event.add("QuestBackgroundBuilder", QuestBackgroundBuilder.class);
            event.add("BackgroundEffects", BackgroundEffects.class);
            event.add("SunBackground", SunBackground.class);
            event.add("GlitchShearBackground", GlitchShearBackground.class);
        }
    }
}
